<?php
/**
 * Laiba Ladies Tailors - Appointment API Endpoint for PHP / MySQL hosting
 * Place this file inside your server's /api/ directory
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database configuration (Change these to match your cPanel / MySQL settings)
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'laiba_tailors';

// Alternative: Fallback to JSON storage if MySQL is not yet configured
$use_json_fallback = true;
$json_file = __DIR__ . '/appointments.json';

// Receive JSON payload or POST form
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    $data = $_POST;
}

$name = isset($data['name']) ? trim($data['name']) : '';
$phone = isset($data['phone']) ? trim($data['phone']) : '';
$service = isset($data['service']) ? trim($data['service']) : '';
$date = isset($data['date']) ? trim($data['date']) : '';
$requirements = isset($data['requirements']) ? trim($data['requirements']) : (isset($data['message']) ? trim($data['message']) : '');

if (empty($name) || empty($phone) || empty($service) || empty($date)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'All required fields (Name, Phone, Service, Date) must be filled.'
    ]);
    exit;
}

$id = 'LLT-' . rand(1000, 9999);
$created_at = date('Y-m-d H:i:s');

// Try MySQL first if connected
$mysqli = @new mysqli($db_host, $db_user, $db_pass, $db_name);

if (!$mysqli->connect_error) {
    $stmt = $mysqli->prepare("INSERT INTO appointments (booking_id, full_name, phone, service, preferred_date, requirements, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)");
    if ($stmt) {
        $stmt->bind_param("sssssss", $id, $name, $phone, $service, $date, $requirements, $created_at);
        $stmt->execute();
        $stmt->close();
        $mysqli->close();

        echo json_encode([
            'success' => true,
            'message' => 'Appointment saved to MySQL database successfully.',
            'appointment' => [
                'id' => $id,
                'name' => $name,
                'phone' => $phone,
                'service' => $service,
                'date' => $date,
                'requirements' => $requirements,
                'status' => 'pending',
                'createdAt' => $created_at
            ]
        ]);
        exit;
    }
}

// Fallback to JSON file storage if MySQL is not yet set up
if ($use_json_fallback) {
    $existing = [];
    if (file_exists($json_file)) {
        $raw = file_get_contents($json_file);
        $existing = json_decode($raw, true) ?: [];
    }

    $newAppointment = [
        'id' => $id,
        'name' => $name,
        'phone' => $phone,
        'service' => $service,
        'date' => $date,
        'requirements' => $requirements,
        'status' => 'pending',
        'createdAt' => $created_at
    ];

    array_unshift($existing, $newAppointment);
    file_put_contents($json_file, json_encode($existing, JSON_PRETTY_PRINT));

    echo json_encode([
        'success' => true,
        'message' => 'Appointment saved to local store successfully.',
        'appointment' => $newAppointment
    ]);
    exit;
}

http_response_code(500);
echo json_encode(['success' => false, 'error' => 'Database connection failed.']);
