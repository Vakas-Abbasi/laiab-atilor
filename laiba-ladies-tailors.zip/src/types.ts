export interface Appointment {
  id: string;
  name: string;
  phone: string;
  service: string;
  date: string;
  requirements: string;
  status: 'pending' | 'confirmed' | 'completed';
  createdAt: string;
}

export interface ServiceItem {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  tagline: string;
  price: string;
  featured?: boolean;
  features: string[];
}
