import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle2,
  Calendar,
  Phone,
  Scissors,
  MapPin,
  MessageCircle,
  X,
  Copy,
  Check,
} from 'lucide-react';
import { Appointment } from '../types';

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment | null;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({
  isOpen,
  onClose,
  appointment,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !appointment) return null;

  const handleCopyId = () => {
    navigator.clipboard.writeText(appointment.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsAppSend = () => {
    const whatsappNumber = '923248276429';
    const message =
      `Assalam-o-Alaikum Laiba Ladies Tailors!%0A%0A` +
      `Maine website per appointment book ki hai:%0A` +
      `📌 *Booking ID:* ${encodeURIComponent(appointment.id)}%0A` +
      `👤 *Name:* ${encodeURIComponent(appointment.name)}%0A` +
      `📞 *Phone:* ${encodeURIComponent(appointment.phone)}%0A` +
      `👗 *Service:* ${encodeURIComponent(appointment.service)}%0A` +
      `📅 *Preferred Date:* ${encodeURIComponent(appointment.date)}%0A` +
      `📝 *Requirements:* ${encodeURIComponent(appointment.requirements || 'Standard Fitting')}%0A%0A` +
      `Kindly confirm my stitching slot. Thank you!`;

    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
  };

  return (
    <AnimatePresence>
      <div
        id="appointment-success-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          id="appointment-success-card"
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-rose-100 my-8 overflow-hidden text-stone-800"
        >
          {/* Close button */}
          <button
            id="modal-close-btn"
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="absolute top-5 right-5 w-9 h-9 flex items-center justify-center rounded-full bg-stone-100 hover:bg-stone-200 text-stone-500 hover:text-stone-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Success Icon */}
          <div className="text-center pt-2">
            <div
              id="success-icon-badge"
              className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white shadow-lg shadow-emerald-500/20 mb-4"
            >
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200/60 mb-2">
              Saved to Database ✓
            </span>

            <h3
              id="success-modal-heading"
              className="text-2xl sm:text-3xl font-semibold font-display text-stone-900"
            >
              Appointment Confirmed!
            </h3>

            {/* Urdu subtitle */}
            <p
              id="success-modal-urdu"
              className="text-sm text-stone-500 mt-1 font-normal"
            >
              آپ کی اپائنٹمنٹ کامیابی کے ساتھ محفوظ ہو چکی ہے
            </p>
          </div>

          {/* Reference ID Pill */}
          <div
            id="booking-reference-pill"
            className="flex items-center justify-between bg-rose-50/80 border border-rose-100 rounded-xl px-4 py-2.5 my-5"
          >
            <div className="text-left">
              <span className="text-xs uppercase tracking-wider text-rose-600 font-semibold block">
                Booking Reference ID
              </span>
              <span className="text-base font-bold text-stone-900 font-mono">
                {appointment.id}
              </span>
            </div>
            <button
              type="button"
              onClick={handleCopyId}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-700 hover:text-rose-800 bg-white px-2.5 py-1.5 rounded-lg border border-rose-200/80 shadow-xs cursor-pointer transition"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy ID</span>
                </>
              )}
            </button>
          </div>

          {/* Reassuring message lines */}
          <div className="space-y-2.5 text-stone-600 text-sm bg-stone-50 p-4 rounded-2xl border border-stone-200/60">
            <p className="flex items-start gap-2.5">
              <span className="text-rose-500 font-bold mt-0.5">•</span>
              <span>
                <strong className="text-stone-900">Shukriya {appointment.name}!</strong> Aap
                ki booking request hamare master tailor record me save ho chuki hai.
              </span>
            </p>
            <p className="flex items-start gap-2.5">
              <span className="text-rose-500 font-bold mt-0.5">•</span>
              <span>
                Hamari team jald hi aap ke number (<strong className="text-stone-900">{appointment.phone}</strong>)
                per WhatsApp ya call karegi taake fitting aur time confirm kar sakein.
              </span>
            </p>
            <p className="flex items-start gap-2.5 text-xs text-stone-500">
              <MapPin className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
              <span>
                Shop: School Road, Block 4, Gulistan-e-Johar, Karachi (Rehana Muneer)
              </span>
            </p>
          </div>

          {/* Summary Box */}
          <div className="grid grid-cols-2 gap-3 my-5 text-left text-xs sm:text-sm">
            <div className="p-3 bg-white rounded-xl border border-stone-200">
              <span className="text-stone-400 text-xs flex items-center gap-1 mb-1">
                <Scissors className="w-3.5 h-3.5 text-rose-500" />
                Service
              </span>
              <strong className="text-stone-800 block truncate">
                {appointment.service}
              </strong>
            </div>

            <div className="p-3 bg-white rounded-xl border border-stone-200">
              <span className="text-stone-400 text-xs flex items-center gap-1 mb-1">
                <Calendar className="w-3.5 h-3.5 text-rose-500" />
                Date
              </span>
              <strong className="text-stone-800 block">
                {appointment.date}
              </strong>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2.5">
            <button
              id="modal-send-whatsapp-btn"
              type="button"
              onClick={handleWhatsAppSend}
              className="w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl text-white font-medium bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-600/20 active:scale-[0.99] transition cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 fill-white" />
              <span>Send Confirmation on WhatsApp</span>
            </button>

            <button
              id="modal-dismiss-btn"
              type="button"
              onClick={onClose}
              className="w-full py-2.5 rounded-xl text-stone-600 hover:text-stone-800 text-sm font-medium hover:bg-stone-100 transition cursor-pointer"
            >
              Close Window
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
