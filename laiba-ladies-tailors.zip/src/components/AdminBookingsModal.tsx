import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Database,
  Search,
  Phone,
  Calendar,
  Clock,
  Trash2,
  RefreshCw,
  MessageCircle,
  CheckCircle,
} from 'lucide-react';
import { Appointment } from '../types';

interface AdminBookingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointments: Appointment[];
  onRefresh: () => void;
  onDelete: (id: string) => Promise<void>;
  onStatusChange: (id: string, status: 'pending' | 'confirmed' | 'completed') => Promise<void>;
}

export const AdminBookingsModal: React.FC<AdminBookingsModalProps> = ({
  isOpen,
  onClose,
  appointments,
  onRefresh,
  onDelete,
  onStatusChange,
}) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'pending' | 'confirmed' | 'completed'>('all');
  const [loadingAction, setLoadingAction] = useState<string | null>(null);

  if (!isOpen) return null;

  const filtered = appointments.filter((app) => {
    const matchesSearch =
      app.name.toLowerCase().includes(search.toLowerCase()) ||
      app.phone.toLowerCase().includes(search.toLowerCase()) ||
      app.service.toLowerCase().includes(search.toLowerCase()) ||
      app.id.toLowerCase().includes(search.toLowerCase());

    const matchesFilter = filter === 'all' ? true : app.status === filter;

    return matchesSearch && matchesFilter;
  });

  const handleWhatsApp = (app: Appointment) => {
    // Format phone: remove non-digits
    let cleanPhone = app.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '92' + cleanPhone.slice(1);
    }
    const msg = `Assalam-o-Alaikum ${app.name}, this is from Laiba Ladies Tailors regarding your booking #${app.id} for ${app.service}. How can we assist you with measurements & fitting?`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleStatus = async (id: string, newStatus: 'pending' | 'confirmed' | 'completed') => {
    setLoadingAction(id);
    await onStatusChange(id, newStatus);
    setLoadingAction(null);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this appointment from the database?')) {
      setLoadingAction(id);
      await onDelete(id);
      setLoadingAction(null);
    }
  };

  return (
    <AnimatePresence>
      <div
        id="admin-bookings-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/70 backdrop-blur-sm overflow-hidden"
        onClick={onClose}
      >
        <motion.div
          id="admin-bookings-dialog"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden border border-stone-200"
        >
          {/* Header */}
          <div className="p-5 sm:p-6 border-b border-stone-200 flex items-center justify-between bg-stone-50/70">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-display text-stone-900 flex items-center gap-2">
                  Database Appointments
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 font-mono font-bold">
                    {appointments.length} Total
                  </span>
                </h3>
                <p className="text-xs text-stone-500">
                  Real-time storage for client bookings at Laiba Ladies Tailors
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onRefresh}
                title="Refresh database"
                className="p-2 rounded-xl text-stone-600 hover:text-stone-900 hover:bg-stone-200/70 transition cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-stone-600 hover:text-stone-900 hover:bg-stone-200/70 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="p-4 border-b border-stone-100 flex flex-col sm:flex-row gap-3 bg-white">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by client name, phone, service, or #ID..."
                className="w-full pl-9 pr-4 py-2 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500"
              />
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl text-xs">
              {(['all', 'pending', 'confirmed', 'completed'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg capitalize font-medium transition cursor-pointer ${
                    filter === tab
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Appointments List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3 bg-stone-50/40">
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-stone-400">
                <Database className="w-10 h-10 mx-auto mb-2 opacity-40" />
                <p className="font-medium text-stone-600">No appointments found</p>
                <p className="text-xs text-stone-400">
                  {search ? 'Try adjusting your search criteria.' : 'New bookings will appear here instantly.'}
                </p>
              </div>
            ) : (
              filtered.map((item) => (
                <div
                  key={item.id}
                  className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-xs hover:border-rose-200 transition"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100">
                          {item.id}
                        </span>
                        <h4 className="font-semibold text-stone-900 text-base">
                          {item.name}
                        </h4>
                      </div>
                      <div className="flex flex-wrap items-center gap-4 text-xs text-stone-500 mt-1">
                        <span className="flex items-center gap-1 font-medium text-stone-700">
                          <Phone className="w-3.5 h-3.5 text-stone-400" />
                          {item.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-stone-400" />
                          Preferred: <strong>{item.date}</strong>
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-stone-400" />
                          {new Date(item.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Status select */}
                      <select
                        value={item.status}
                        disabled={loadingAction === item.id}
                        onChange={(e) =>
                          handleStatus(
                            item.id,
                            e.target.value as 'pending' | 'confirmed' | 'completed'
                          )
                        }
                        className={`text-xs font-medium px-2.5 py-1.5 rounded-lg border cursor-pointer focus:outline-hidden ${
                          item.status === 'confirmed'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : item.status === 'completed'
                            ? 'bg-blue-50 text-blue-700 border-blue-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                        }`}
                      >
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="completed">Completed</option>
                      </select>

                      {/* WhatsApp contact */}
                      <button
                        type="button"
                        onClick={() => handleWhatsApp(item)}
                        title="Chat with client on WhatsApp"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-white" />
                        <span>Chat</span>
                      </button>

                      {/* Delete */}
                      <button
                        type="button"
                        onClick={() => handleDelete(item.id)}
                        disabled={loadingAction === item.id}
                        title="Delete record"
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Requirements & Service details */}
                  <div className="pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs gap-2">
                    <div className="text-stone-600">
                      <span className="font-semibold text-stone-800">Service: </span>
                      <span className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-800 font-medium">
                        {item.service}
                      </span>
                    </div>

                    {item.requirements && (
                      <p className="text-stone-500 italic max-w-md truncate">
                        "{item.requirements}"
                      </p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer note */}
          <div className="p-4 bg-stone-100 text-stone-600 text-xs flex flex-col sm:flex-row items-center justify-between border-t border-stone-200 gap-2">
            <span>
              💡 <strong>Storage:</strong> All records are saved in the Express/Node backend database (<code className="text-rose-700 font-mono">data/appointments.json</code>) and accessible via API.
            </span>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50 cursor-pointer"
            >
              Done
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
