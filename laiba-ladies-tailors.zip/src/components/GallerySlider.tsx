import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

const galleryItems = [
  {
    id: 1,
    title: 'Elegant Ladies Suit',
    subtitle: 'Design 01',
    image: 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 2,
    title: 'Traditional Suit',
    subtitle: 'Design 02',
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 3,
    title: 'Simple Shirt',
    subtitle: 'Design 03',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 4,
    title: 'Modern Ladies Wear',
    subtitle: 'Design 04',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 5,
    title: 'Premium Suit',
    subtitle: 'Design 05',
    image: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 6,
    title: 'Classic Outfit',
    subtitle: 'Design 06',
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 7,
    title: 'Festive Dress',
    subtitle: 'Design 07',
    image: 'https://images.unsplash.com/photo-1506629905607-d9c297d7a78b?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 8,
    title: 'Formal Ladies Dress',
    subtitle: 'Design 08',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 9,
    title: 'Designer Outfit',
    subtitle: 'Design 09',
    image: 'https://images.unsplash.com/photo-1496217590455-aa63a8350eea?auto=format&fit=crop&w=1600&q=85',
  },
  {
    id: 10,
    title: 'Beautiful Ladies Wear',
    subtitle: 'Design 10',
    image: 'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=1600&q=85',
  },
];

export const GallerySlider: React.FC = () => {
  const [current, setCurrent] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (isHovered) return;
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % galleryItems.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [isHovered]);

  const prevSlide = () => {
    setCurrent((prev) => (prev === 0 ? galleryItems.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrent((prev) => (prev + 1) % galleryItems.length);
  };

  return (
    <div
      id="gallery-slider-container"
      className="relative max-w-4xl mx-auto rounded-3xl overflow-hidden shadow-xl border border-rose-100 bg-stone-900 aspect-16/10 sm:aspect-16/9 group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Slider Track */}
      <div
        className="flex w-full h-full transition-transform duration-500 ease-out"
        style={{ transform: `translateX(-${current * 100}%)` }}
      >
        {galleryItems.map((item) => (
          <div key={item.id} className="min-w-full h-full relative shrink-0">
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover"
              loading="lazy"
            />
            {/* Dark gradient overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent flex flex-col justify-end p-6 sm:p-10">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-rose-300 mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                {item.subtitle}
              </span>
              <h3 className="text-2xl sm:text-3xl font-display font-semibold text-white">
                {item.title}
              </h3>
              <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-md">
                Handcrafted stitching with meticulous piping and finishing by Laiba Ladies Tailors.
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Prev / Next Arrows */}
      <button
        id="gallery-prev-btn"
        type="button"
        onClick={prevSlide}
        aria-label="Previous slide"
        className="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/80 hover:bg-white text-stone-800 flex items-center justify-center backdrop-blur-xs shadow-md transition opacity-80 hover:opacity-100 cursor-pointer"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        id="gallery-next-btn"
        type="button"
        onClick={nextSlide}
        aria-label="Next slide"
        className="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/80 hover:bg-white text-stone-800 flex items-center justify-center backdrop-blur-xs shadow-md transition opacity-80 hover:opacity-100 cursor-pointer"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10 bg-black/30 backdrop-blur-xs px-3 py-1.5 rounded-full">
        {galleryItems.map((_, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => setCurrent(idx)}
            aria-label={`Go to slide ${idx + 1}`}
            className={`transition-all rounded-full cursor-pointer ${
              current === idx
                ? 'w-6 h-2 bg-rose-500'
                : 'w-2 h-2 bg-white/60 hover:bg-white'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
