/**
 * Laiba Ladies Tailors - Full Application with Database Storage & Confirmation Modal
 * @license Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Scissors,
  Calendar,
  Phone,
  MapPin,
  Heart,
  Tag,
  Check,
  ArrowRight,
  Menu,
  X,
  User,
  Database,
  Shirt,
  Sparkles,
  Layers,
  Ruler,
  Clock,
  Send,
  MessageCircle,
} from 'lucide-react';
import { Appointment } from './types';
import { SuccessModal } from './components/SuccessModal';
import { AdminBookingsModal } from './components/AdminBookingsModal';
import { GallerySlider } from './components/GallerySlider';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [recentAppointment, setRecentAppointment] = useState<Appointment | null>(null);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Form inputs
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: '',
    date: '',
    requirements: '',
  });

  // Calculate today's date in YYYY-MM-DD for min date
  const today = new Date().toISOString().split('T')[0];

  // Fetch appointments from API on mount
  const fetchAppointments = async () => {
    try {
      const res = await fetch('/api/appointments');
      if (res.ok) {
        const data = await res.json();
        if (data.appointments) {
          setAppointments(data.appointments);
          // Cache in localStorage as local fallback
          localStorage.setItem('laiba_appointments', JSON.stringify(data.appointments));
        }
      } else {
        // Fallback to localStorage if API unavailable
        const local = localStorage.getItem('laiba_appointments');
        if (local) setAppointments(JSON.parse(local));
      }
    } catch (err) {
      console.warn('Backend fetch error, reading local cache:', err);
      const local = localStorage.getItem('laiba_appointments');
      if (local) setAppointments(JSON.parse(local));
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  // Form submission handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!formData.name.trim() || !formData.phone.trim() || !formData.service || !formData.date) {
      setSubmitError('Please fill in all required fields (Name, Phone, Service, Date).');
      return;
    }

    setSubmitting(true);

    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (response.ok && result.success && result.appointment) {
        const newApp: Appointment = result.appointment;

        // Update state
        setAppointments((prev) => [newApp, ...prev]);
        setRecentAppointment(newApp);
        setIsSuccessModalOpen(true);

        // Reset form
        setFormData({
          name: '',
          phone: '',
          service: '',
          date: '',
          requirements: '',
        });
      } else {
        throw new Error(result.error || 'Failed to record appointment in database.');
      }
    } catch (err: any) {
      console.error('Submission error:', err);
      // Fallback: save to client state & localStorage if network/server is interrupted
      const fallbackId = `LLT-${Math.floor(1000 + Math.random() * 9000)}`;
      const fallbackApp: Appointment = {
        id: fallbackId,
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        service: formData.service,
        date: formData.date,
        requirements: formData.requirements.trim() || 'Standard stitching',
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      const updated = [fallbackApp, ...appointments];
      setAppointments(updated);
      localStorage.setItem('laiba_appointments', JSON.stringify(updated));

      setRecentAppointment(fallbackApp);
      setIsSuccessModalOpen(true);

      setFormData({
        name: '',
        phone: '',
        service: '',
        date: '',
        requirements: '',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (
    id: string,
    status: 'pending' | 'confirmed' | 'completed'
  ) => {
    try {
      await fetch(`/api/appointments/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      setAppointments((prev) =>
        prev.map((item) => (item.id === id ? { ...item, status } : item))
      );
    } catch (err) {
      console.error('Status update error:', err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/appointments/${id}`, { method: 'DELETE' });
      setAppointments((prev) => prev.filter((item) => item.id !== id));
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fdfbfb] text-stone-800">
      {/* =====================================================
           HEADER / NAVBAR
      ====================================================== */}
      <header
        id="main-header"
        className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-rose-100 shadow-xs transition-all duration-300"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            id="brand-logo"
            className="flex items-center gap-2.5 text-2xl sm:text-3xl font-bold font-display text-stone-900 group"
          >
            <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shadow-md shadow-rose-500/20 group-hover:scale-105 transition">
              <Scissors className="w-5 h-5 -rotate-45" />
            </div>
            <span>
              Laiba <span className="text-rose-600 font-medium">Ladies Tailors</span>
            </span>
          </a>

          {/* Desktop Nav Links */}
          <nav id="desktop-nav" className="hidden lg:flex items-center gap-7 text-sm font-medium text-stone-600">
            <a href="#home" className="hover:text-rose-600 transition">Home</a>
            <a href="#about" className="hover:text-rose-600 transition">About</a>
            <a href="#services" className="hover:text-rose-600 transition">Services</a>
            <a href="#gallery" className="hover:text-rose-600 transition">Gallery</a>
            <a href="#pricing" className="hover:text-rose-600 transition">Prices</a>
            <a href="#appointment" className="hover:text-rose-600 transition">Appointment</a>
            <a href="#contact" className="hover:text-rose-600 transition">Contact</a>
          </nav>

          {/* Right Action buttons */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Database Bookings Button (Admin View) */}
            <button
              id="header-admin-db-btn"
              type="button"
              onClick={() => setIsAdminModalOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-rose-50 text-stone-700 hover:text-rose-700 border border-stone-200 transition cursor-pointer"
              title="View saved appointments in database"
            >
              <Database className="w-4 h-4 text-rose-600" />
              <span>Bookings ({appointments.length})</span>
            </button>

            <a
              href="#appointment"
              id="header-book-now-cta"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-600/25 active:scale-95 transition"
            >
              <span>Book Now</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAdminModalOpen(true)}
              className="p-2 rounded-xl bg-stone-100 text-rose-600"
              title="Database Bookings"
            >
              <Database className="w-5 h-5" />
            </button>

            <button
              id="mobile-menu-toggle"
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-rose-100 bg-white px-4 pt-3 pb-6 space-y-3 shadow-lg">
            <a
              href="#home"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              Home
            </a>
            <a
              href="#about"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              About
            </a>
            <a
              href="#services"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              Services
            </a>
            <a
              href="#gallery"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              Gallery
            </a>
            <a
              href="#pricing"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              Prices
            </a>
            <a
              href="#appointment"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              Appointment
            </a>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-stone-700 hover:text-rose-600 font-medium"
            >
              Contact
            </a>

            <div className="pt-3 border-t border-stone-100 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsAdminModalOpen(true);
                }}
                className="w-full py-2.5 text-center rounded-xl bg-stone-100 text-stone-800 text-sm font-semibold flex items-center justify-center gap-2"
              >
                <Database className="w-4 h-4 text-rose-600" />
                <span>View Database Bookings ({appointments.length})</span>
              </button>

              <a
                href="#appointment"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 text-center rounded-xl bg-rose-600 text-white text-sm font-semibold shadow-md shadow-rose-600/20"
              >
                Book Appointment
              </a>
            </div>
          </div>
        )}
      </header>

      {/* Main Content Container */}
      <main className="flex-1">
        {/* ===================================================
             HERO SECTION
        ==================================================== */}
        <section
          id="home"
          className="relative pt-12 pb-20 sm:pt-20 sm:pb-28 overflow-hidden bg-gradient-to-b from-rose-50/50 via-white to-[#fdfbfb]"
        >
          {/* Subtle background decorative shapes */}
          <div className="absolute top-0 right-0 -mr-32 -mt-32 w-96 h-96 rounded-full bg-rose-200/30 blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-32 -mb-32 w-80 h-80 rounded-full bg-amber-100/40 blur-3xl pointer-events-none" />

          <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center relative z-10">
            {/* Tag badge */}
            <div
              id="hero-tag"
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-rose-100/80 text-rose-800 text-xs sm:text-sm font-semibold uppercase tracking-wider mb-6 border border-rose-200/70"
            >
              <Scissors className="w-3.5 h-3.5 text-rose-600" />
              <span>Laiba Ladies Tailor</span>
            </div>

            <h1
              id="hero-title"
              className="text-4xl sm:text-6xl md:text-7xl font-bold font-display tracking-tight text-stone-900 leading-[1.15] mb-6"
            >
              Laiba <span className="text-rose-600 italic">Ladies Tailors</span>
            </h1>

            <p
              id="hero-desc"
              className="max-w-2xl mx-auto text-stone-600 text-base sm:text-lg leading-relaxed mb-10"
            >
              Welcome to Laiba Ladies Tailors — where traditional craftsmanship meets modern style.
              We stitch all kinds of ladies suits with beautiful finishing, custom measurements, and precision fitting.
            </p>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <a
                href="#appointment"
                id="hero-primary-cta"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full text-base font-semibold text-white bg-rose-600 hover:bg-rose-700 shadow-xl shadow-rose-600/30 active:scale-98 transition cursor-pointer"
              >
                <span>Book Your Stitching</span>
                <ArrowRight className="w-5 h-5" />
              </a>

              <a
                href="#gallery"
                id="hero-secondary-cta"
                className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 rounded-full text-base font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 shadow-xs hover:border-stone-400 transition"
              >
                View Our Designs
              </a>
            </div>

            {/* Quick feature pills */}
            <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs sm:text-sm text-stone-600 pt-6 border-t border-rose-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-600">
                  <MapPin className="w-4 h-4" />
                </div>
                <span>Gulistan-e-Johar, Karachi</span>
              </div>

              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-600">
                  <Tag className="w-4 h-4" />
                </div>
                <span>Prices From Rs. 1,000</span>
              </div>

              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-600">
                  <Heart className="w-4 h-4 text-rose-600 fill-rose-600" />
                </div>
                <span>Made With Care</span>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
             ABOUT SECTION
        ==================================================== */}
        <section id="about" className="py-16 sm:py-24 bg-white border-y border-stone-100">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              {/* Image with badge */}
              <div className="relative">
                <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-stone-100 aspect-4/3 sm:aspect-5/4">
                  <img
                    src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=85"
                    alt="Ladies Tailoring Craftsmanship"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                </div>

                {/* Floating badge */}
                <div className="absolute -bottom-6 -right-4 sm:bottom-6 sm:-left-6 bg-white p-4 sm:p-5 rounded-2xl shadow-xl border border-rose-100 flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold text-lg font-display">
                    100%
                  </div>
                  <div>
                    <strong className="block text-stone-900 text-sm sm:text-base">Custom Stitching</strong>
                    <span className="text-xs text-stone-500">Perfect measurements & fitting</span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                  About Laiba Ladies Tailors
                </span>
                <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 leading-tight mb-6">
                  Your fabric. <br />
                  <span className="text-rose-600 italic">Your style.</span> <br />
                  Our expertise.
                </h2>

                <p className="text-stone-600 text-base leading-relaxed mb-4">
                  Laiba Ladies Tailors is dedicated to providing quality ladies tailoring with beautiful
                  fitting, clean finishing, and attention to detail.
                </p>

                <p className="text-stone-600 text-base leading-relaxed mb-6">
                  We stitch a wide range of ladies outfits including shirts, shalwar, gharara, trousers,
                  and specially designed suits with custom dori and piping work.
                </p>

                <ul className="space-y-3 mb-8 text-stone-700 text-sm sm:text-base">
                  <li className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span>All kinds of ladies suits & boutique styles</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span>Custom measurements and guaranteed comfortable fitting</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span>Designer dori, lace, and matching piping designs</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span>Bring your own fabric and get it stitched to perfection</span>
                  </li>
                </ul>

                <a
                  href="#appointment"
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-white font-medium bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-600/25 transition"
                >
                  <span>Book Fitting Appointment</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
             SERVICES SECTION
        ==================================================== */}
        <section id="services" className="py-16 sm:py-24 bg-[#fdfbfb]">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                Our Expertise
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 mb-4">
                Tailoring Services
              </h2>
              <p className="text-stone-600 text-sm sm:text-base">
                From simple daily wear to detailed traditional outfits, we stitch according to your preferred style and specifications.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {/* Card 1 */}
              <div className="p-7 rounded-3xl bg-white border border-rose-100/80 shadow-sm hover:shadow-md hover:border-rose-300 transition duration-300 group">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition">
                  <Shirt className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display text-stone-900 mb-2">Ladies Shirts</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Elegant simple and designer shirts stitched according to your preferred fitting, neckline, and sleeve style.
                </p>
              </div>

              {/* Card 2 */}
              <div className="p-7 rounded-3xl bg-white border border-rose-100/80 shadow-sm hover:shadow-md hover:border-rose-300 transition duration-300 group">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition">
                  <Scissors className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display text-stone-900 mb-2">Shalwar</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Traditional shalwar stitching with accurate measurements, neat plate pleats, and comfortable finishing.
                </p>
              </div>

              {/* Card 3 */}
              <div className="p-7 rounded-3xl bg-white border border-rose-100/80 shadow-sm hover:shadow-md hover:border-rose-300 transition duration-300 group">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display text-stone-900 mb-2">Gharara</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Beautiful gharara stitching with flare volume for festive, wedding, and special traditional occasions.
                </p>
              </div>

              {/* Card 4 */}
              <div className="p-7 rounded-3xl bg-white border border-rose-100/80 shadow-sm hover:shadow-md hover:border-rose-300 transition duration-300 group">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition">
                  <Ruler className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display text-stone-900 mb-2">Trousers</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Custom trouser stitching with comfortable fitting, clean straight cuts, pant style, and professional finishing.
                </p>
              </div>

              {/* Card 5 */}
              <div className="p-7 rounded-3xl bg-white border border-rose-100/80 shadow-sm hover:shadow-md hover:border-rose-300 transition duration-300 group">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition">
                  <Layers className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display text-stone-900 mb-2">Dori & Piping</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Decorative dori, fabric buttons, and piping work to give your suit a refined and personalized boutique look.
                </p>
              </div>

              {/* Card 6 */}
              <div className="p-7 rounded-3xl bg-white border border-rose-100/80 shadow-sm hover:shadow-md hover:border-rose-300 transition duration-300 group">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:bg-rose-600 group-hover:text-white transition">
                  <Scissors className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display text-stone-900 mb-2">Bring Your Own Fabric</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Have your unstitched lawn, silk, or chiffon fabric? Bring it to our shop and we will stitch it to your design.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
             GALLERY SLIDER SECTION
        ==================================================== */}
        <section id="gallery" className="py-16 sm:py-24 bg-white border-t border-stone-100">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                Our Work
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 mb-4">
                Suit Gallery
              </h2>
              <p className="text-stone-600 text-sm sm:text-base">
                Explore examples of different ladies suit styles, traditional designs, and everyday tailored outfits.
              </p>
            </div>

            {/* Interactive Slider Component */}
            <GallerySlider />
          </div>
        </section>

        {/* ===================================================
             PRICING SECTION
        ==================================================== */}
        <section id="pricing" className="py-16 sm:py-24 bg-[#fdfbfb]">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                Our Rates
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 mb-4">
                Starting Prices
              </h2>
              <p className="text-stone-600 text-sm sm:text-base">
                Prices may vary depending on design intricacy, fabric type, finishing, and custom stitching requirements.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
              {/* Plan 1 */}
              <div className="bg-white rounded-3xl p-8 border border-stone-200 shadow-sm flex flex-col justify-between hover:border-rose-200 transition">
                <div>
                  <h3 className="text-2xl font-bold font-display text-stone-900 mb-2">Simple</h3>
                  <p className="text-stone-500 text-sm mb-6">Simple everyday ladies suit stitching.</p>

                  <div className="mb-6">
                    <span className="text-3xl font-extrabold text-stone-900 font-display">Rs. 1,000</span>
                    <span className="text-stone-400 text-sm ml-1">/ starting</span>
                  </div>

                  <ul className="space-y-3 text-sm text-stone-600 mb-8">
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Basic suit stitching</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Custom measurements</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Standard clean finishing</span>
                    </li>
                  </ul>
                </div>

                <a
                  href="#appointment"
                  className="w-full text-center py-3 rounded-xl border border-stone-300 hover:border-stone-400 text-stone-800 font-medium text-sm transition"
                >
                  Book Now
                </a>
              </div>

              {/* Plan 2 (Popular) */}
              <div className="relative bg-white rounded-3xl p-8 border-2 border-rose-500 shadow-xl flex flex-col justify-between scale-105 z-10">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-rose-600 text-white text-xs font-bold uppercase tracking-wider py-1 px-4 rounded-full shadow-md">
                  Most Popular
                </div>

                <div>
                  <h3 className="text-2xl font-bold font-display text-stone-900 mb-2">Designer</h3>
                  <p className="text-stone-500 text-sm mb-6">Detailed suits with additional design & work.</p>

                  <div className="mb-6">
                    <span className="text-3xl font-extrabold text-rose-600 font-display">Rs. 2,000</span>
                    <span className="text-stone-400 text-sm ml-1">/ starting</span>
                  </div>

                  <ul className="space-y-3 text-sm text-stone-600 mb-8">
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Custom measurements & fit</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Detailed pattern stitching</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Dori / piping options included</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Superior boutique finishing</span>
                    </li>
                  </ul>
                </div>

                <a
                  href="#appointment"
                  className="w-full text-center py-3.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm shadow-md shadow-rose-600/25 transition"
                >
                  Book Now
                </a>
              </div>

              {/* Plan 3 */}
              <div className="bg-white rounded-3xl p-8 border border-stone-200 shadow-sm flex flex-col justify-between hover:border-rose-200 transition">
                <div>
                  <h3 className="text-2xl font-bold font-display text-stone-900 mb-2">Special</h3>
                  <p className="text-stone-500 text-sm mb-6">Gharara, formal, and festive traditional outfits.</p>

                  <div className="mb-6">
                    <span className="text-3xl font-extrabold text-stone-900 font-display">Rs. 3,000</span>
                    <span className="text-stone-400 text-sm ml-1">/ starting</span>
                  </div>

                  <ul className="space-y-3 text-sm text-stone-600 mb-8">
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Detailed bridal/party measurements</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Custom flare & panel design</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Special festive lace & finishing</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className="w-4 h-4 text-rose-600" />
                      <span>Direct consultation with master</span>
                    </li>
                  </ul>
                </div>

                <a
                  href="#appointment"
                  className="w-full text-center py-3 rounded-xl border border-stone-300 hover:border-stone-400 text-stone-800 font-medium text-sm transition"
                >
                  Book Now
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
             PROCESS SECTION
        ==================================================== */}
        <section className="py-16 sm:py-20 bg-white border-y border-stone-100">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                How It Works
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 mb-2">
                Simple Ordering Process
              </h2>
              <p className="text-stone-600 text-sm">Getting your suit stitched is easy and convenient.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Step 1 */}
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="text-3xl font-display font-extrabold text-rose-600 mb-3">01</div>
                <h3 className="text-lg font-bold text-stone-900 mb-1">Choose</h3>
                <p className="text-stone-600 text-xs sm:text-sm">Select your preferred design, neckline, and stitching style.</p>
              </div>

              {/* Step 2 */}
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="text-3xl font-display font-extrabold text-rose-600 mb-3">02</div>
                <h3 className="text-lg font-bold text-stone-900 mb-1">Measure</h3>
                <p className="text-stone-600 text-xs sm:text-sm">We take your exact measurements for a flawless, flattering fit.</p>
              </div>

              {/* Step 3 */}
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="text-3xl font-display font-extrabold text-rose-600 mb-3">03</div>
                <h3 className="text-lg font-bold text-stone-900 mb-1">Stitch</h3>
                <p className="text-stone-600 text-xs sm:text-sm">Your selected suit is carefully stitched with precision and finished.</p>
              </div>

              {/* Step 4 */}
              <div className="p-6 rounded-2xl bg-stone-50 border border-stone-100">
                <div className="text-3xl font-display font-extrabold text-rose-600 mb-3">04</div>
                <h3 className="text-lg font-bold text-stone-900 mb-1">Collect</h3>
                <p className="text-stone-600 text-xs sm:text-sm">Collect your finished outfit from our shop in Gulistan-e-Johar.</p>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
             OWNER SECTION
        ==================================================== */}
        <section className="py-16 sm:py-20 bg-[#fdfbfb]">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="bg-white rounded-3xl p-8 sm:p-12 border border-rose-100 shadow-md text-center">
              <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center mx-auto mb-6">
                <User className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-bold font-display text-stone-900 mb-1">
                Rehana Muneer
              </h2>
              <h4 className="text-sm font-semibold text-rose-600 uppercase tracking-wider mb-6">
                Owner — Laiba Ladies Tailors
              </h4>
              <p className="text-stone-600 text-base leading-relaxed max-w-2xl mx-auto">
                Laiba Ladies Tailors is managed with a focus on quality stitching, customer satisfaction,
                and professional service. Our shop and appointments are handled with care to provide
                customers with a smooth, reliable, and convenient tailoring experience in Gulistan-e-Johar, Karachi.
              </p>
            </div>
          </div>
        </section>

        {/* ===================================================
             APPOINTMENT BOOKING FORM WITH DATABASE STORAGE & POPUP
        ==================================================== */}
        <section id="appointment" className="py-20 sm:py-28 bg-white border-t border-stone-100">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                Book Your Stitching
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 mb-4">
                Make an Appointment
              </h2>
              <p className="text-stone-600 text-sm sm:text-base">
                Your details are stored securely in our database, and you will receive an instant confirmation popup.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
              {/* Left Info Column */}
              <div className="lg:col-span-5 bg-gradient-to-br from-rose-50 to-stone-50 p-8 rounded-3xl border border-rose-100">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-600 block mb-2">
                  Laiba Ladies Tailors
                </span>
                <h3 className="text-2xl font-bold font-display text-stone-900 mb-4">
                  Let's stitch your next favourite outfit.
                </h3>
                <p className="text-stone-600 text-sm leading-relaxed mb-8">
                  Fill in your details to book your stitching slot. We will record your appointment in our database and contact you to confirm timing.
                </p>

                <div className="space-y-4 text-sm text-stone-700">
                  <div className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-stone-100">
                    <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs text-stone-400 block">Primary Contact</span>
                      <strong className="text-stone-900">+92 324 8276429</strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-stone-100">
                    <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs text-stone-400 block">WhatsApp / Alternate</span>
                      <strong className="text-stone-900">+92 312 3513658</strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-stone-100">
                    <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs text-stone-400 block">Shop Address</span>
                      <span className="text-stone-900 font-medium">School Road, Block 4, Gulistan-e-Johar, Karachi</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-stone-100">
                    <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <Tag className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs text-stone-400 block">Pricing</span>
                      <span className="text-stone-900 font-medium">Stitching starts from Rs. 1,000</span>
                    </div>
                  </div>
                </div>

                {/* Database notice */}
                <div className="mt-8 p-4 rounded-2xl bg-white/80 border border-emerald-200/80 text-xs text-emerald-800 flex items-start gap-2.5">
                  <Database className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <span>
                    <strong>Database Storage Active:</strong> Every submission is recorded on the server and generates a unique confirmation code (#LLT-XXXX).
                  </span>
                </div>
              </div>

              {/* Right Form Column */}
              <div className="lg:col-span-7 bg-white p-8 sm:p-10 rounded-3xl border border-stone-200 shadow-xl">
                <form id="appointmentForm" onSubmit={handleSubmit} className="space-y-5">
                  {submitError && (
                    <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-sm">
                      {submitError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Full Name */}
                    <div>
                      <label htmlFor="name" className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
                        Full Name *
                      </label>
                      <input
                        id="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Fatima Ali"
                        className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 transition"
                      />
                    </div>

                    {/* Phone */}
                    <div>
                      <label htmlFor="phone" className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
                        Phone / WhatsApp *
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+92 3XX XXXXXXX"
                        className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 transition"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Service */}
                    <div>
                      <label htmlFor="service" className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
                        Service *
                      </label>
                      <select
                        id="service"
                        required
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 transition cursor-pointer"
                      >
                        <option value="">Select a service</option>
                        <option value="Ladies Shirt">Ladies Shirt</option>
                        <option value="Shalwar">Shalwar</option>
                        <option value="Gharara">Gharara</option>
                        <option value="Trouser">Trouser</option>
                        <option value="Dori / Piping Suit">Dori / Piping Suit</option>
                        <option value="Bring My Own Fabric">Bring My Own Fabric</option>
                        <option value="Complete 3-Piece Suit">Complete 3-Piece Suit</option>
                        <option value="Other">Other Custom Design</option>
                      </select>
                    </div>

                    {/* Date */}
                    <div>
                      <label htmlFor="date" className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
                        Preferred Date *
                      </label>
                      <input
                        id="date"
                        type="date"
                        required
                        min={today}
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 transition cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Requirements / message */}
                  <div>
                    <label htmlFor="message" className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
                      Requirements (Optional)
                    </label>
                    <textarea
                      id="message"
                      rows={3}
                      value={formData.requirements}
                      onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                      placeholder="Tell us about your suit, design, neck style, or stitching requirements..."
                      className="w-full px-4 py-3 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 transition"
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <button
                    id="appointment-submit-btn"
                    type="submit"
                    disabled={submitting}
                    className="w-full flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl text-white font-semibold text-base bg-rose-600 hover:bg-rose-700 shadow-xl shadow-rose-600/30 active:scale-[0.99] transition cursor-pointer disabled:opacity-70"
                  >
                    {submitting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Saving to Database...</span>
                      </>
                    ) : (
                      <>
                        <span>Confirm & Save Appointment</span>
                        <Send className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <p className="text-center text-xs text-stone-400">
                    🔒 Data is saved directly to the database. A confirmation pop-up will appear with your booking summary and WhatsApp link.
                  </p>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
             CONTACT SECTION WITH MAP
        ==================================================== */}
        <section id="contact" className="py-16 sm:py-24 bg-[#fdfbfb] border-t border-stone-100">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-600 mb-2 block">
                Visit Our Shop
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 mb-4">
                Contact Us
              </h2>
              <p className="text-stone-600 text-sm sm:text-base">
                For appointments, stitching inquiries, or custom measurements, visit or contact Laiba Ladies Tailors.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
              {/* Shop info card */}
              <div className="bg-white rounded-3xl p-8 sm:p-10 border border-stone-200 shadow-sm flex flex-col justify-between">
                <div>
                  <h3 className="text-2xl font-bold font-display text-stone-900 mb-6">
                    Shop Information
                  </h3>

                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 mt-1">
                        <MapPin className="w-5 h-5" />
                      </div>
                      <div>
                        <strong className="block text-stone-900 text-sm sm:text-base font-semibold">
                          Address
                        </strong>
                        <span className="text-stone-600 text-sm">
                          School Road, Block 4, Gulistan-e-Johar, Karachi, Pakistan
                        </span>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 mt-1">
                        <Phone className="w-5 h-5" />
                      </div>
                      <div>
                        <strong className="block text-stone-900 text-sm sm:text-base font-semibold">
                          Phone
                        </strong>
                        <a
                          href="tel:+923248276429"
                          className="text-stone-600 text-sm hover:text-rose-600 transition"
                        >
                          +92 324 8276429
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0 mt-1">
                        <MessageCircle className="w-5 h-5" />
                      </div>
                      <div>
                        <strong className="block text-stone-900 text-sm sm:text-base font-semibold">
                          WhatsApp
                        </strong>
                        <a
                          href="https://wa.me/923123513658"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-stone-600 text-sm hover:text-emerald-600 transition"
                        >
                          +92 312 3513658
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 mt-1">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <strong className="block text-stone-900 text-sm sm:text-base font-semibold">
                          Owner
                        </strong>
                        <span className="text-stone-600 text-sm">
                          Rehana Muneer
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                  <span>Open: Mon – Sat (11:00 AM – 9:00 PM)</span>
                  <span className="text-emerald-600 font-semibold">● Open Now</span>
                </div>
              </div>

              {/* Google Map Box */}
              <div className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-sm min-h-[350px]">
                <iframe
                  title="Shop Location"
                  src="https://www.google.com/maps?q=Gulistan-e-Johar%20Karachi&output=embed"
                  className="w-full h-full min-h-[350px] border-0"
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* =====================================================
           FOOTER
      ====================================================== */}
      <footer className="bg-stone-900 text-stone-300 py-12 border-t border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 text-2xl font-bold font-display text-white mb-2">
              <Scissors className="w-5 h-5 text-rose-500" />
              <span>
                Laiba <span className="text-rose-400">Ladies Tailors</span>
              </span>
            </div>
            <p className="text-xs text-stone-400">
              © 2026 Laiba Ladies Tailors. All rights reserved. Gulistan-e-Johar, Karachi.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setIsAdminModalOpen(true)}
              className="px-3.5 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-rose-400 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Admin Database ({appointments.length})</span>
            </button>

            <a
              href="https://wa.me/923248276429"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full bg-stone-800 hover:bg-emerald-600 text-stone-300 hover:text-white flex items-center justify-center transition"
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-4 h-4" />
            </a>
          </div>
        </div>
      </footer>

      {/* =====================================================
           FLOATING WHATSAPP BUTTON
      ====================================================== */}
      <a
        id="floating-whatsapp-btn"
        href="https://wa.me/923248276429?text=Assalam-o-Alaikum%20Laiba%20Ladies%20Tailors,%20I%20have%20an%20inquiry%20regarding%20suit%20stitching."
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-200"
        title="Chat on WhatsApp"
      >
        <MessageCircle className="w-7 h-7 fill-white" />
      </a>

      {/* =====================================================
           SUCCESS POPUP MODAL (User's specific request)
      ====================================================== */}
      <SuccessModal
        isOpen={isSuccessModalOpen}
        onClose={() => setIsSuccessModalOpen(false)}
        appointment={recentAppointment}
      />

      {/* =====================================================
           ADMIN DATABASE BOOKINGS MODAL
      ====================================================== */}
      <AdminBookingsModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        appointments={appointments}
        onRefresh={fetchAppointments}
        onDelete={handleDelete}
        onStatusChange={handleStatusChange}
      />
    </div>
  );
}
